<?php
namespace models;

    class reservation extends database {
        public function Insert(array $data){
            $this->SendData("INSERT INTO `reservation` (  `Date_reserve`, `Time_reserve`, `Nbre_table`) VALUES (?,?,?)",$data);
        }
        
        // public function 
    }
