<?php
namespace models;

include_once 'Assets/Config/env.php';


abstract class database
{

    /*
     * Fonction de connexion à la DBB en POO
     */

    protected function ConnectDB()
    {
        try {
            $bdd = new \PDO("mysql:host=" . $_ENV['host'] . ";dbname=" . $_ENV['bdd'], $_ENV['userbd'], $_ENV['password']);
            $bdd->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            return $bdd;
        } catch (\PDOException $e) {
            return " Une erreur est retrouvée : " . $e->getMessage();
        }
    }

    /*
    Fonction d'envoi de données.
    */

    protected function SendData(string $request, array $data)
    {
        try {
            $bdd = $this->ConnectDB();
            $requette = $bdd->prepare($request);
            $requette->execute($data);
        } catch (\PDOException $e) {
            return " Une erreur est retrouvée : " . $e->getMessage();
        }
    }

    /*
     * Fonction de recupération d'une ligne.
     */

    protected function GetOneData(string $request, ?array $data=NULL)
    {
        try {
            $bdd = $this->ConnectDB();
            $requette = $bdd->prepare($request);
            $requette->execute($data);
            return $requette->fetch(\PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {
            return " Une erreur est retrouvée : " . $e->getMessage();
        }
    }
    /*
     * Fonction de recupération multi-lignes.
     */
    
    protected function GetManyData($request, ?array $data=NULL)
    {
       
       
        try {
            $bdd = $this->ConnectDB();
            $requette = $bdd->prepare($request);
            $requette->execute($data);
            return $requette->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {
            return " Une erreur est retrouvée : " . $e->getMessage();
        }
    }
}
