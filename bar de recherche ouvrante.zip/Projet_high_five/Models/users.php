<?php

namespace models;

class users extends database  implements base {
public function Insert(array $data){
    $this->SendData("INSERT INTO users (Nom, Prénoms, Identifiant, Mot_de_passe) VALUES (?,?,?,?)",$data);
}
public function Update(array $data){
    $this->SendData("UPDATE users SET Nom=?,Prénoms=?,Identifiant=?,Mot_de_passe=? WHERE ID=?",$data);
}
public function Delete(int $id){
    $this->SendData("DELETE FROM users WHERE ID=?",[$id]);
}
public function GetAll(): array{
    return $this->GetManyData("SELECT ID,Nom, Prénoms, Identifiant FROM users",NULL);
}
public function GetById(int $id){
    return $this->GetOneData("SELECT ID,Nom, Prénoms, Identifiant FROM users WHERE Id=?",[$id]);
}
public function Recherches(array $data){
   return $this->GetManyData("SELECT ID, Nom, Prénoms, Identifiant FROM users WHERE Nom=? or Prénoms=? or Identifiant=?" , $data);
}
public function GetUserByLogin(string $login){
    return $this->GetOneData("SELECT ID, Nom, Prénoms, Identifiant, Mot_de_passe FROM users WHERE Identifiant=?",[$login]);
}
}