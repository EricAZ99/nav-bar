<?php
namespace controllers;
interface base
{
    public function index();
    public function store();
    public function update();
    public function destroy();    
}