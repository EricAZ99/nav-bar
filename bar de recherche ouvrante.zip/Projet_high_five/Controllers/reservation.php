<?php
namespace controllers;
class reservation 
{
    private $ModelReserv;
    use \controllers\utils;
    public function __construct()
    {
        $this->ModelReserv=new \models\reservation(); 

        $_SESSION['links']=$this->GetLinks();
        
        if(isset($_GET['target'])){
            $target=$_GET['target'];
            $this->$target(); 
        }else{
            $this->index();
        }
    }
    public function index()
    {
        $template='views/page/reservation.phtml';
        include_once 'views/main.phtml';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (isset($_POST['reserv_date']) && isset($_POST['reserv_heure']) && isset($_POST['Nbre_table'])) {
                $this->ModelReserv->Insert([$_POST['reserv_date'], $_POST['reserv_heure'], $_POST['Nbre_table']]);
                header("location: index.php?goto=reservation");
                        exit();
            }
        }
    }

    // public function 
}