<?php
$_ENV['userbd']='root';
$_ENV['host']='localhost';
$_ENV['bdd']='topchrist';
$_ENV['password']='';