// let profil = document.getElementById('profil');
// let display = document.getElementById('display');

// profil.addEventListener('click', function(){
//     display.style.display = 'none';
// })